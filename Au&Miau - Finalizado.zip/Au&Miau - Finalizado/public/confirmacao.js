document.addEventListener("DOMContentLoaded", function() {
    const selection = JSON.parse(localStorage.getItem('appointmentSelection')) || {};
    const petInfo = JSON.parse(localStorage.getItem('petInfo')) || {};
    const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
    const unitSelection = JSON.parse(localStorage.getItem('unitSelection')) || {};

    // Preencher os campos com os dados salvos
    document.getElementById('pet-name').innerText = petInfo.name || 'Não especificado';
    document.getElementById('tutor-name').innerText = userInfo.name || 'Não especificado';
    document.getElementById('bath-type').innerText = petInfo.bathType || 'Não especificado';
    document.getElementById('grooming-type').innerText = petInfo.groomingType || 'Não especificado';
    document.getElementById('additional-services').innerText = petInfo.additionalServices ? petInfo.additionalServices.join(', ') : 'Não especificado';
    document.getElementById('unit-name').innerText = unitSelection.unit || 'Não especificado';
    document.getElementById('appointment-date').innerText = selection.date || 'Não especificado';
    document.getElementById('appointment-time').innerText = selection.time || 'Não especificado';

    // Definir valores e tempos dos serviços
    const serviceDetails = {
        'banho-simples': { value: 50, time: 30 },
        'banho-premium': { value: 80, time: 45 },
        'tosa-tesoura': { value: 70, time: 30 },
        'tosa-maquina': { value: 60, time: 20 },
        'tosa-higienica': { value: 40, time: 10 },
        'corte-unhas': { value: 15, time: 15 },
        'escovacao-dentes': { value: 30, time: 30 },
        'tesoura-rosto': { value: 15, time: 15 },
        'hidratacao': { value: 20, time: 15 }
    };

    // Calcular valor total e tempo total
    let totalValue = 0;
    let totalTime = 0;

    if (petInfo.bathType && serviceDetails[petInfo.bathType]) {
        totalValue += serviceDetails[petInfo.bathType].value;
        totalTime += serviceDetails[petInfo.bathType].time;
    }

    if (petInfo.groomingType && serviceDetails[petInfo.groomingType]) {
        totalValue += serviceDetails[petInfo.groomingType].value;
        totalTime += serviceDetails[petInfo.groomingType].time;
    }

    if (petInfo.additionalServices) {
        petInfo.additionalServices.forEach(service => {
            if (serviceDetails[service]) {
                totalValue += serviceDetails[service].value;
                totalTime += serviceDetails[service].time;
            }
        });
    }

    // Exibir valor total e tempo total
    document.getElementById('total-value').innerText = `R$ ${totalValue}`;
    document.getElementById('total-time').innerText = `${totalTime} minutos`;
});
