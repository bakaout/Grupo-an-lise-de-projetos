document.querySelector('.complete-data-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value.replace(/\D/g, ''); // Remove parênteses, espaços e hífens
    const cpf = document.getElementById('cpf').value.replace(/\D/g, ''); // Remove pontos e hífens
    const senha = document.getElementById('senha').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const street = document.getElementById('street').value;
    const number = document.getElementById('number').value;
    const cep = document.getElementById('cep').value.replace(/\D/g, ''); // Remove hífens

    // Verifica se todos os campos estão preenchidos
    if (!name || !email || !phone || !cpf || !senha || !confirmPassword || !street || !number || !cep) {
        displayError('Todos os campos devem estar preenchidos.');
        return;
    }

    // Verifica se o telefone contém exatamente 11 números
    if (!/^\d{11}$/.test(phone)) {
        displayError('O telefone deve conter exatamente 11 números.');
        return;
    }

    // Verifica se o CPF contém exatamente 11 números
    if (!/^\d{11}$/.test(cpf)) {
        displayError('O CPF deve conter exatamente 11 números.');
        return;
    }

    // Verifica se as senhas coincidem
    if (senha !== confirmPassword) {
        displayError('As senhas não coincidem.');
        return;
    }

    // Limita o CEP a 8 caracteres
    if (cep.length !== 8) {
        displayError('O CEP deve conter exatamente 8 caracteres.');
        return;
    }

    fetch('/cadastrarTutor', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, email, phone, cpf, street, number, cep, senha })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            localStorage.setItem('userId', data.userId); // Armazena o ID do tutor cadastrado
            window.location.href = 'selecionarPet.html'; // Redirecionar para a página de seleção de pet
        } else {
            displayError('Ocorreu um erro ao cadastrar. Tente novamente.');
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        displayError('Ocorreu um erro ao cadastrar. Tente novamente.');
    });
});

document.getElementById('senha').addEventListener('input', checkPasswords);
document.getElementById('confirm-password').addEventListener('input', checkPasswords);

function checkPasswords() {
    const senha = document.getElementById('senha').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    if (senha !== confirmPassword) {
        displayError('As senhas não coincidem.');
    } else {
        clearError();
    }
}

function displayError(message) {
    const errorDiv = document.getElementById('register-error');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
}

function clearError() {
    const errorDiv = document.getElementById('register-error');
    errorDiv.textContent = '';
    errorDiv.style.display = 'none';
}

// Função para permitir apenas números nos campos especificados
function allowOnlyNumbers(event) {
    const input = event.target;
    input.value = input.value.replace(/\D/g, '');
}

document.getElementById('phone').addEventListener('input', function(event) {
    allowOnlyNumbers(event);
    if (event.target.value.length > 11) {
        event.target.value = event.target.value.slice(0, 11);
    }
});

document.getElementById('cpf').addEventListener('input', function(event) {
    allowOnlyNumbers(event);
    if (event.target.value.length > 11) {
        event.target.value = event.target.value.slice(0, 11);
    }
});

document.getElementById('number').addEventListener('input', function(event) {
    allowOnlyNumbers(event)
});
