document.addEventListener('DOMContentLoaded', () => {
    const petsList = document.getElementById('pets-list');
    const emailTutor = localStorage.getItem('EmailTutor'); // Obtém o email do usuário logado

    fetch(`/obterTutorPorEmail?email=${emailTutor}`)
        .then(response => response.json())
        .then(tutor => {
            localStorage.setItem('userInfo', JSON.stringify({ name: tutor.Nome })); // Armazena o nome do tutor

            fetch(`/obterPetsPorEmail?email=${emailTutor}`)
                .then(response => response.json()) // Use json() para converter a resposta
                .then(pets => {
                    console.log(pets); // Verifique a resposta JSON
                    if (pets.length === 0) {
                        petsList.innerHTML = '<p>Nenhum pet cadastrado</p>';
                        return;
                    }

                    petsList.innerHTML = pets.map(pet => `
                        <div class="pet-item">
                            <label>
                                <input type="radio" name="pet" value="${pet.Nome}">
                                ${pet.Nome}
                            </label>
                        </div>
                    `).join('');

                    petsList.innerHTML += `
                        <button id="select-pet" class="register-pet-button">Selecionar Pet</button>
                    `;

                    document.getElementById('select-pet').addEventListener('click', () => {
                        const selectedPet = document.querySelector('input[name="pet"]:checked');
                        if (selectedPet) {
                            const petInfo = JSON.parse(localStorage.getItem('petInfo')) || {};
                            petInfo.name = selectedPet.value;
                            localStorage.setItem('petInfo', JSON.stringify(petInfo)); // Armazena o nome do pet
                            window.location.href = 'servico.html'; // Redireciona para a página de serviço
                        } else {
                            alert('Por favor, selecione um pet.');
                        }
                    });
                })
                .catch(error => {
                    console.error('Erro ao obter pets:', error);
                    petsList.innerHTML = '<p>Erro ao carregar pets cadastrados.</p>';
                });
        })
        .catch(error => {
            console.error('Erro ao obter dados do tutor:', error);
            petsList.innerHTML = '<p>Erro ao carregar dados do tutor.</p>';
        });
});
