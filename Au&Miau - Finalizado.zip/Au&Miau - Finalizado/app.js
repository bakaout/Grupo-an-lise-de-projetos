const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors'); // Adicione esta linha

const app = express();
app.use(bodyParser.json());
app.use(cors()); // Adicione esta linha

const conexao = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'db_auemiau'
});

conexao.connect(function(erro) {
    if (erro) throw erro;
    console.log('Conexao Efetuada');
});

// Servir arquivos estáticos da pasta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Rota para a raiz
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


// Rota para obter pets pelo email do tutor
app.get('/obterPetsPorEmail', (req, res) => {
    const email = req.query.email;
    const sql = `
        SELECT Pet.*
        FROM Pet
        JOIN Tutor ON Pet.IdTutor = Tutor.idTutor
        WHERE Tutor.Email = ?
    `;
    
    conexao.query(sql, [email], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao obter pets:', erro);
            res.status(500).json({ error: 'Erro ao obter pets' });
            return;
        }
        console.log(resultados); // Adicione este log para verificar os resultados
        if (resultados.length > 0) {
            res.setHeader('Content-Type', 'application/json'); // Certifique-se de definir o cabeçalho
            res.json(resultados);
        } else {
            res.status(404).send('Nenhum pet encontrado para este tutor.');
        }
    });
});



// Rota para cadastrar tutor
app.post('/cadastrarTutor', (req, res) => {
    const { name, email, phone, cpf, street, number, cep, senha } = req.body;

    if (!name || !email || !phone || !cpf || !street || !number || !cep || !senha) {
        return res.status(400).send('Por favor, preencha todos os campos obrigatórios.');
    }

    const sql = 'INSERT INTO Tutor (Nome, Telefone, CPF, Rua, Numero, CEP, Email, Senha) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
    const values = [name, phone, cpf, street, number, cep, email, senha];

    conexao.query(sql, values, (erro, resultado) => {
        if (erro) throw erro;
        const userId = resultado.insertId; // Obtém o ID do tutor recém-cadastrado
        res.json({ success: true, userId });
    });
});

// Rota para cadastrar pet
app.post('/cadastrarPet', (req, res) => {
    const { name, breed, size, gender, temperament, birthdate, observacao, tipo, IdTutor } = req.body;

    if (!name || !breed || !size || !gender || !temperament || !birthdate || !tipo || !IdTutor) {
        return res.status(400).send('Por favor, preencha todos os campos obrigatórios.');
    }

    const sql = 'INSERT INTO Pet (Nome, Tipo, Sexo, Raca, Porte, Temperamento, DataNasc, Observacao, idTutor) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
    const values = [name, tipo, gender, breed, size, temperament, birthdate, observacao, idTutor];

    conexao.query(sql, values, (erro, resultado) => {
        if (erro) throw erro;
        res.send('Pet cadastrado com sucesso!');
    });
});

// Rota para obter serviços
app.get('/obterServicos', (req, res) => {
    const sql = 'SELECT * FROM Servico';

    conexao.query(sql, (erro, resultados) => {
        if (erro) throw erro;
        res.json(resultados);
    });
});

// Rota para login
app.post('/login', (req, res) => {
    const { email, senha } = req.body;

    if (!email || !senha) {
        return res.status(400).send('Por favor, preencha todos os campos obrigatórios.');
    }

    const sql = 'SELECT * FROM Tutor WHERE Email = ? AND Senha = ?';
    const values = [email, senha];

    conexao.query(sql, values, (erro, resultados) => {
        if (erro) throw erro;

        if (resultados.length > 0) {
            res.json({ success: true, userId: resultados[0].idTutor });
        } else {
            res.json({ success: false });
        }
    });
});

// Rota para obter dados do tutor pelo email
app.get('/obterTutorPorEmail', (req, res) => {
    const email = req.query.email;
    const sql = 'SELECT * FROM Tutor WHERE Email = ?';
    
    conexao.query(sql, [email], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao obter dados do tutor:', erro);
            res.status(500).json({ error: 'Erro ao obter dados do tutor' });
            return;
        }
        if (resultados.length > 0) {
            res.json(resultados[0]);
        } else {
            res.status(404).send('Nenhum tutor encontrado com este email.');
        }
    });
});


app.listen(8080, () => {
    console.log('Servidor rodando na porta 8080');
});
