document.querySelector('.pet-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const breed = document.getElementById('breed').value;
    const size = document.getElementById('size').value;
    const gender = document.getElementById('gender').value;
    const temperament = document.getElementById('temperament').value;
    const birthdate = document.getElementById('birthdate').value;
    const idtutor = document.getElementById('idtutor').value;

    if (!name || !breed || !size || !gender || !temperament || !birthdate) {
        alert('Por favor, preencha todos os campos obrigatórios.');
        return;
    }

    const petData = { name, breed, size, gender, temperament, birthdate, idtutor };

    fetch('/cadastrarPet', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(petData)
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        window.location.href = 'selecionarPet.html'; // Redireciona para a página de seleção de pet
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Ocorreu um erro ao cadastrar o pet.');
    });
});
